# placeholder file.
# this is sample content which is left in there for reference purposes and also to ensure that maven build scripts work. this should be removed